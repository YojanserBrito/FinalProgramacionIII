﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea.Models
{

    [Table("Producto", Schema = "dbo")]
    public class Producto
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        [Column(TypeName ="Varchar(50)")]
        [Display(Name = "Nombre Producto")]
        public string Nombre_Producto { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        public double Precio { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        public int Candidad_Disponible { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        [Column(TypeName = "Varchar(50)")]
        [Display(Name = "Nombre Imagen")]
        public string Nombre_Imagen { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        public string Ruta_Imagen { get; set; }

        //Foreign Key Categoria
        public int Id_Categoria { get; set; }

        [ForeignKey("Id_Categoria")]
        public virtual Categoria Categoria { get; set; }

    }
}
