﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea.Models
{
    public class UsuarioRol
    {

        [DisplayName("Usuario Id")]
        public string UserId { get; set; }

        [DisplayName("Nombre de usuario")]
        public string UserName { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public bool EstaSeleccionado { get; set; }

    }
}
