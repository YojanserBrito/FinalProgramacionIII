﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea.Models
{

    [Table("Carrito", Schema = "dbo")]
    public class Carrito 
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string Id_Usuario { get; set; }    //Foreign Key del Identity

        [ForeignKey("Id_Usuario")]
        public Otra_Info_De_Usuario Usuario { get; set; }
        public string Estado { get; set; }


    }
}
