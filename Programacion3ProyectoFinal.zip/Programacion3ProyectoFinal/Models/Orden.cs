﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea.Models
{

    [Table("Orden", Schema = "dbo")]
    public class Orden    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        [Display(Name = "Cantidad Producto")]
        public int Cantidad_Producto { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        public double Precio_Unitario { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        public System.DateTime Fecha_Creacion  { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        public double Monto_Orden  { get; set; }

        [Column(TypeName = "varchar(10)")]
        public string Estado { get; set; }   

        public string Id_Usuario { get; set; }    //Foreign Key del Identity

        [ForeignKey("Id_Usuario")]
        public virtual Otra_Info_De_Usuario Usuario { get; set; }

        public int Id_Producto { get; set; } //Foreign Key del Producto

        [ForeignKey("Id_Producto")]
        public virtual Producto Producto { get; set; }
    }
}
