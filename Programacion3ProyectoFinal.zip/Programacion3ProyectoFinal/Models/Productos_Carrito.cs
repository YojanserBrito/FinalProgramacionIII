﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea.Models
{

    [Table("Productos_Carrito", Schema = "dbo")]
    public class Productos_Carrito
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public int Id_Carrito { get; set; }

        [ForeignKey("Id_Carrito")]
        public virtual Carrito Carrito { get; set; }
        public int Id_Producto { get; set; }
        public int Cantidad_Producto { get; set; }

        [ForeignKey("Id_Producto")]
        public virtual Producto Producto { get; set; }



    }
}
