﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Tarea.Models
{
    public class Otra_Info_De_Usuario : IdentityUser
    {

        [Column(TypeName = "varchar(50)")]
        [Required(ErrorMessage = "Este campo es obligatorio")]
        public string Latitud { get; set; }

        [Column(TypeName = "varchar(50)")]
        [Required(ErrorMessage = "Este campo es obligatorio")]
        public string Longitud { get; set; }


        [Column(TypeName = "varchar(50)")]
        [Required(ErrorMessage = "Este campo es obligatorio")]
        public string Nombre { get; set; }

        [Column(TypeName = "varchar(50)")]
        [Required(ErrorMessage = "Este campo es obligatorio")]
        public string Apellidos { get; set; }

        [DisplayFormat(DataFormatString ="{0:dd/MM/yyyy}", ApplyFormatInEditMode =true)]
        [Required(ErrorMessage = "Este campo es obligatorio")]
        [DataType(DataType.Date)]
        [Display(Name ="Fecha De Nacimento")]
        public System.DateTime Fecha_Nacimiento { get; set; }

        [Required(ErrorMessage = "Este campo es obligatorio")]
        [Column(TypeName = ("Varchar(200)"))]
        public string Direccion { get; set; }

        [Display(Name = "Comentario Direccion")]
        [Column(TypeName =("Varchar(300)"))]
        public string Comentario_Direccion { get; set; }

    }
}
