﻿
    $(document).ready(function () {
        $('ul.pagination > li.disabled > a').addClass('page-link');
    });
    
    
    
    // Mapa
    var mapa = L.map('mapa').setView([18.48, -69.87], 7);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(mapa);
    
    var markers = new L.FeatureGroup();
    
    $("#mes").change(function () {
        alert("klk");
        $.getJSON("/Clientes/MesNacimiento", { mes: $("#mes").val() }, function (d) { });
    
    });
    
    
    $("#estado").change(function () {
        
        $.getJSON("/Clientes/ListaDePedidos", { estado: $("#estado").val() }, function (d) {
            $.each(d, function (i, v) {
                var marker = L.marker([v.latitud, v.longitud]).addTo(mapa)
                    .bindPopup('<h6>Estado:</h6>' + v.estado + ' <h6>Nombre:</h6>' + v.nombre +
                        ' <h6>Apellidos:</h6>' + v.apellidos + ' <h6>Direccion:</h6>' + v.direccion +
                        ' <h6>Comentario:</h6>' + v.comentario_Direccion)
                    .openPopup();  
                     
                markers.addLayer(marker);
                
            });
        });
        removerMarcadores(); 
        mapa.addLayer(markers);
    });
    
    
    function removerMarcadores() {
        mapa.removeLayer(markers);
    
    }
    
    function confirmarBorrar(idInico, esVerdadero) {
    
        var borrarSpan = 'borrarSpan_' + idInico;
        var confirmarBorrarSpan = 'confirmarBorrarSpan_' + idInico;
    
        if (esVerdadero) {
            $('#' + borrarSpan).hide();
            $('#' + confirmarBorrarSpan).show();
        }
        else {
            $('#' + borrarSpan).show();
            $('#' + confirmarBorrarSpan).hide();
        }
    }
    
    