﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Tarea.Data.Migrations
{
    public partial class Nuestra_Migracion : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.AddColumn<string>(
                name: "Apellidos",
                table: "AspNetUsers",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Comentario_Direccion",
                table: "AspNetUsers",
                type: "Varchar(300)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Direccion",
                table: "AspNetUsers",
                type: "Varchar(200)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "Fecha_Nacimiento",
                table: "AspNetUsers",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "Latitud",
                table: "AspNetUsers",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Longitud",
                table: "AspNetUsers",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Nombre",
                table: "AspNetUsers",
                type: "varchar(50)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "Carrito",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Id_Usuario = table.Column<string>(nullable: true),
                    Estado = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Carrito", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Carrito_AspNetUsers_Id_Usuario",
                        column: x => x.Id_Usuario,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Categoria",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Nombre_Categoria = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categoria", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Slider",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Nombre = table.Column<string>(nullable: false),
                    Path = table.Column<string>(nullable: false),
                    Activo = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Slider", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Producto",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Nombre_Producto = table.Column<string>(type: "Varchar(50)", nullable: false),
                    Precio = table.Column<double>(nullable: false),
                    Candidad_Disponible = table.Column<int>(nullable: false),
                    Nombre_Imagen = table.Column<string>(type: "Varchar(50)", nullable: false),
                    Ruta_Imagen = table.Column<string>(nullable: false),
                    Id_Categoria = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Producto", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Producto_Categoria_Id_Categoria",
                        column: x => x.Id_Categoria,
                        principalSchema: "dbo",
                        principalTable: "Categoria",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Orden",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Cantidad_Producto = table.Column<int>(nullable: false),
                    Precio_Unitario = table.Column<double>(nullable: false),
                    Fecha_Creacion = table.Column<DateTime>(nullable: false),
                    Monto_Orden = table.Column<double>(nullable: false),
                    Estado = table.Column<string>(type: "varchar(10)", nullable: true),
                    Id_Usuario = table.Column<string>(nullable: true),
                    Id_Producto = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orden", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Orden_Producto_Id_Producto",
                        column: x => x.Id_Producto,
                        principalSchema: "dbo",
                        principalTable: "Producto",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Orden_AspNetUsers_Id_Usuario",
                        column: x => x.Id_Usuario,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Productos_Carrito",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Id_Carrito = table.Column<int>(nullable: false),
                    Id_Producto = table.Column<int>(nullable: false),
                    Cantidad_Producto = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Productos_Carrito", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Productos_Carrito_Carrito_Id_Carrito",
                        column: x => x.Id_Carrito,
                        principalSchema: "dbo",
                        principalTable: "Carrito",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Productos_Carrito_Producto_Id_Producto",
                        column: x => x.Id_Producto,
                        principalSchema: "dbo",
                        principalTable: "Producto",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Carrito_Id_Usuario",
                schema: "dbo",
                table: "Carrito",
                column: "Id_Usuario");

            migrationBuilder.CreateIndex(
                name: "IX_Orden_Id_Producto",
                schema: "dbo",
                table: "Orden",
                column: "Id_Producto");

            migrationBuilder.CreateIndex(
                name: "IX_Orden_Id_Usuario",
                schema: "dbo",
                table: "Orden",
                column: "Id_Usuario");

            migrationBuilder.CreateIndex(
                name: "IX_Producto_Id_Categoria",
                schema: "dbo",
                table: "Producto",
                column: "Id_Categoria");

            migrationBuilder.CreateIndex(
                name: "IX_Productos_Carrito_Id_Carrito",
                schema: "dbo",
                table: "Productos_Carrito",
                column: "Id_Carrito");

            migrationBuilder.CreateIndex(
                name: "IX_Productos_Carrito_Id_Producto",
                schema: "dbo",
                table: "Productos_Carrito",
                column: "Id_Producto");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Orden",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Productos_Carrito",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Slider",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Carrito",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Producto",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Categoria",
                schema: "dbo");

            migrationBuilder.DropColumn(
                name: "Apellidos",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Comentario_Direccion",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Direccion",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Fecha_Nacimiento",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Latitud",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Longitud",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Nombre",
                table: "AspNetUsers");
        }
    }
}
