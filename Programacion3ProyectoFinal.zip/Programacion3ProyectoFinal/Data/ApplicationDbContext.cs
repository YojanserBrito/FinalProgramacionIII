﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Tarea.Models;

namespace Tarea.Data
{
    public class ApplicationDbContext : IdentityDbContext<Otra_Info_De_Usuario>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        

        protected override void OnModelCreating(ModelBuilder builder)
        {

            base.OnModelCreating(builder);
           
        }
        public DbSet<Categoria> Categoria { get; set; }
        public DbSet<Producto> Producto { get; set; }
        public DbSet<Carrito> Carrito { get; set; }
        public DbSet<Productos_Carrito> Productos_Carrito { get; set; }
        public DbSet<Orden> Orden { get; set; }
        public DbSet<Slider> Slider { get; set; }


    }
}
