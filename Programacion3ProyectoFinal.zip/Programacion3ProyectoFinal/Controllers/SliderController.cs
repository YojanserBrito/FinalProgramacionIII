﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipelines;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Tarea.Data;
using Tarea.Models;

namespace Tarea.Controllers
{
    public class SliderController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHost;

        public SliderController(ApplicationDbContext context, IWebHostEnvironment webHost)
        {
            _context = context;
            _webHost = webHost;
        }

        // GET: Slider
        public async Task<IActionResult> Index()
        {
            return View(await _context.Slider.ToListAsync());
        }

        // GET: Slider/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var slider = await _context.Slider
                .FirstOrDefaultAsync(m => m.Id == id);
            if (slider == null)
            {
                return NotFound();
            }

            return View(slider);
        }

        public IActionResult CrearActualizar()
        {
            ViewBag.primerSlide = _context.Slider.Where(x => x.Id == 1).Select(y => y.Path).FirstOrDefault();
            ViewBag.segundoSlide = _context.Slider.Where(x => x.Id == 2).Select(y => y.Path).FirstOrDefault();
            ViewBag.tercerSlide = _context.Slider.Where(x => x.Id == 3).Select(y => y.Path).FirstOrDefault();
            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public async Task<IActionResult> CrearActualizar(IFormFile img, Slider slider,int id)
        {
            
            if (id == 0)
            {
                ViewData["Posicion"] = "Debes seleccionar una posicion para el slider, Intentalo otra vez";
                return View();
            }
            var existe = _context.Slider.Where(x=>x.Id == id).FirstOrDefault();
            if (existe == null)
            {
                try
                {
                    string tipoImg = Path.GetExtension(img.FileName);

                    if (tipoImg == ".jpg" || tipoImg == ".gif" || tipoImg == ".png")
                    {
                        var myUniqueFileName = Convert.ToString(Guid.NewGuid());

                        var guardarImg = Path.Combine(_webHost.WebRootPath, "Imagenes\\Slider", myUniqueFileName + tipoImg);
                        var stream = new FileStream(guardarImg, FileMode.Create);
                        await img.CopyToAsync(stream);

                        slider.Nombre = myUniqueFileName + tipoImg;
                        slider.Path = "Slider/" + myUniqueFileName + tipoImg;
                        slider.Activo = true;
                        await _context.Slider.AddAsync(slider);
                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        ViewData["Mensaje"] = "Error, favor verificar el tipo de imagen, solamente se aceptan imagenes de tipo .JPG, .PNG y .GIV intente otra vez.";
                        return View();
                    }
                }
                catch (Exception e)
                {
                    ViewData["Mensaje"] = "Favor seleccione una imagen. " + e.Message;
                    return View();
                }
            }
            else
            {
                try
                {
                    string tipoImg = Path.GetExtension(img.FileName);
                    var modelo = _context.Slider.Where(x => x.Id == id).FirstOrDefault();

                    if (tipoImg == ".jpg" || tipoImg == ".gif" || tipoImg == ".png")
                    {
                        var nombreImagen = Convert.ToString(Guid.NewGuid())+ tipoImg;
                        var guardarImg = Path.Combine(_webHost.WebRootPath, "Imagenes\\Slider", nombreImagen);
                        var stream = new FileStream(guardarImg, FileMode.Create);
                        await img.CopyToAsync(stream);

                        modelo.Nombre = nombreImagen;
                        modelo.Path = "Slider/" + nombreImagen;
                         _context.Slider.Update(modelo);
                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        ViewData["Mensaje"] = "Error, favor verificar el tipo de imagen, solamente se aceptan imagenes de tipo .JPG, .PNG y .GIV intente otra vez.";
                        return View();
                    }
                }
                catch (Exception e)
                {
                    ViewData["Mensaje"] = "Favor seleccione una imagen. " + e.Message;
                    return View();
                }
            }
            ViewData["Listo"] = "Slider Subido exitosamente!!";
            ViewBag.primerSlide = _context.Slider.Where(x => x.Id == 1).Select(y => y.Path).FirstOrDefault();
            ViewBag.segundoSlide = _context.Slider.Where(x => x.Id == 2).Select(y => y.Path).FirstOrDefault();
            ViewBag.tercerSlide = _context.Slider.Where(x => x.Id == 3).Select(y => y.Path).FirstOrDefault();
            return View();
        }



        public async Task<IActionResult> EditandoProducto(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var producto = await _context.Producto.FindAsync(id);
            if (producto == null)
            {
                return NotFound();
            }
            return View(producto);
        }

     
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nombre,Path,Activo")] Slider slider)
        {
            if (id != slider.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(slider);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SliderExists(slider.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(slider);
        }

        // GET: Slider/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var slider = await _context.Slider
                .FirstOrDefaultAsync(m => m.Id == id);
            if (slider == null)
            {
                return NotFound();
            }

            return View(slider);
        }

        // POST: Slider/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var slider = await _context.Slider.FindAsync(id);
            _context.Slider.Remove(slider);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SliderExists(int id)
        {
            return _context.Slider.Any(e => e.Id == id);
        }
    }
}
