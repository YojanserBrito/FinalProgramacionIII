﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Tarea.Data;
using Tarea.Models;

namespace Tarea.Controllers
{
    public class AdminController : Controller
    {

        private readonly RoleManager<IdentityRole> roleManager;
        private readonly UserManager<Otra_Info_De_Usuario> userManager;

        public AdminController(RoleManager<IdentityRole> roleManager,
                                UserManager<Otra_Info_De_Usuario> userManager)
        {
            this.roleManager = roleManager;
            this.userManager = userManager;
        }

        [HttpGet]
        public IActionResult CrearRole()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CrearRole(Rol rol)
        {
            if (ModelState.IsValid)
            {
                IdentityRole identityRole = new IdentityRole
                {
                    Name = rol.RoleName
                };

                IdentityResult identityResult = await roleManager.CreateAsync(identityRole);

                if (identityResult.Succeeded)
                {
                    return RedirectToAction("ListaDeRoles", "Admin");
                }

                foreach (IdentityError error in identityResult.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            return View(rol);
        }

        [HttpGet]
        public IActionResult ListaDeRoles() {
            var roles = roleManager.Roles;
            return View(roles);
        }


        [HttpGet]
        public async Task<IActionResult> EditarRol(string Id)
        {
            var rol = await roleManager.FindByIdAsync(Id);

            if (rol == null)
            {
                ViewBag.ErrorMessage = $"No se pudo encontrar Rol con el id {Id}";
                return View("NotFound");
            }

            var modelo = new ModeloEditarRol
            {
                Id = rol.Id,
                RoleName = rol.Name
            };

            foreach (var usuario in userManager.Users)
            {
                if (await userManager.IsInRoleAsync(usuario, rol.Name))
                {
                    modelo.Usuarios.Add("<b> Nombre: </b>"+usuario.Nombre+"<b> Apellidos: </b>"+ usuario.Apellidos+"<b> Correo: </b>"+ usuario.UserName);

                }
            }
            return View(modelo);
        }

        [HttpPost]
        public async Task<IActionResult> EditarRol(ModeloEditarRol modelo)
        {
            var rol = await roleManager.FindByIdAsync(modelo.Id);

            if (rol == null)
            {
                ViewBag.ErrorMessage = $"No se pudo encontrar Rol con el id {modelo.Id}";
                return View("NotFound");
            }
            else
            {
                rol.Name = modelo.RoleName;
                var resultado = await roleManager.UpdateAsync(rol);


                if (resultado.Succeeded)
                {
                    return RedirectToAction("ListaDeRoles");
                }

                foreach (var error in resultado.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
                return View(modelo);
            }
        }

        [HttpGet]
        public async Task<IActionResult> UsuariosEnRol(string rolId)
        {
            ViewBag.rolId = rolId;
            var rol = await roleManager.FindByIdAsync(rolId);
            ViewBag.rolName = rol;

            if (rol == null)
            {
                ViewBag.ErrorMessage = $"No se pudo encontrar Rol con el id {rolId}";
                return View("NotFound");
            }

            var modelo = new List<UsuarioRol>();       

            foreach (var usuario in userManager.Users)
            {
                var modeloUsuarioRol = new UsuarioRol
                {
                    UserId = usuario.Id,
                    UserName = usuario.Email,
                    Nombre = usuario.Nombre,
                    Apellidos = usuario.Apellidos
                };

                if (await userManager.IsInRoleAsync(usuario, rol.Name))
                {
                    modeloUsuarioRol.EstaSeleccionado = true;
                }
                else
                {
                    modeloUsuarioRol.EstaSeleccionado = false;
                }
                modelo.Add(modeloUsuarioRol);
            }

            return View(modelo);
        }

        [HttpPost]
        public async Task<IActionResult> UsuariosEnRol(List<UsuarioRol> modelo, string rolId)
        {
            var rol = await roleManager.FindByIdAsync(rolId);
            
            if (rol == null)
            {
                ViewBag.ErrorMessage = $"No se pudo encontrar Rol con el id {rolId}";
                return View(nameof(NotFound));
            }

            for (int i = 0; i < modelo.Count; i++)
            {
                var usuario = await userManager.FindByIdAsync(modelo[i].UserId);
                IdentityResult resultado = null;

                if (modelo[i].EstaSeleccionado && !(await userManager.IsInRoleAsync(usuario, rol.Name)))
                {
                    resultado = await userManager.AddToRoleAsync(usuario, rol.Name);
                }
                else if(!modelo[i].EstaSeleccionado && await userManager.IsInRoleAsync(usuario, rol.Name))
                {
                    resultado = await userManager.RemoveFromRoleAsync(usuario, rol.Name);
                }
                else
                {
                    continue;
                }
                if (resultado.Succeeded)
                {
                    if (i < (modelo.Count - 1))
                    {
                        continue;
                    }
                    else
                    { 
                        return RedirectToAction("EditarRol", new { Id = rolId });
                    }
                }
            }
            return RedirectToAction("EditarRol", new { Id = rolId });
        }


        [HttpPost, ActionName("BorrarRol")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BorrarRol(string id)
        {
            var rol = await roleManager.FindByIdAsync(id);
            var resultado = await roleManager.DeleteAsync(rol);

            if (resultado.Succeeded)
            {
               return RedirectToAction(nameof(ListaDeRoles));
            }

             foreach (var err in resultado.Errors)
             {
                 ModelState.AddModelError("", err.Description);
             }
            return View(nameof(ListaDeRoles));
        }
    }
}