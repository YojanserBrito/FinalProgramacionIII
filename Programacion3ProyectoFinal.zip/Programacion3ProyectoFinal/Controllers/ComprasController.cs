﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Tarea.Data;

namespace Tarea.Controllers
{
    public class ComprasController : Controller
    {
        private readonly ApplicationDbContext database;

        public ComprasController(ApplicationDbContext database)
        {
            this.database = database;
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}