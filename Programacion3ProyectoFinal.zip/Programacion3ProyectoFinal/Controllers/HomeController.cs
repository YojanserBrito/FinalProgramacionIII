﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Tarea.Data;
using Tarea.Models;
using Microsoft.EntityFrameworkCore;


namespace Tarea.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _database;


        public HomeController(ILogger<HomeController> logger, ApplicationDbContext database)
        {
            _logger = logger;
            _database = database;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            ViewBag.primerSlide = _database.Slider.Where(x => x.Id == 1).Select(y => y.Path).FirstOrDefault();
            ViewBag.segundoSlide = _database.Slider.Where(x => x.Id == 2).Select(y => y.Path).FirstOrDefault();
            ViewBag.tercerSlide = _database.Slider.Where(x => x.Id == 3).Select(y => y.Path).FirstOrDefault();
            
            var productos = _database.Producto.Include(X => X.Categoria);

            return View(await productos.ToListAsync());
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
