using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Tarea.Data;
using Tarea.Models;



namespace Tarea.Controllers
{
    public class CrudProductosController : Controller
    {
        private readonly IHostingEnvironment _environment;

        private readonly ApplicationDbContext _context;

        // Constructor
        public CrudProductosController(IHostingEnvironment IHostingEnvironment, ApplicationDbContext context)
        {
            _context = context;
            _environment = IHostingEnvironment;
        }

        [HttpGet]
        public IActionResult RegistrarProducto()
        {
             ViewBag.Id_Categoria = new SelectList(_context.Categoria, "Id", "Nombre_Categoria");
            return View();
        }

        [HttpPost]
        public IActionResult RegistroProducto(Producto producto)
        {
            var newFileName = string.Empty;

            if (HttpContext.Request.Form.Files != null)
            {
                var fileName = string.Empty;
                string PathDB = string.Empty;

                var files = HttpContext.Request.Form.Files;

                foreach (var file in files)
                {
                    if (file.Length > 0)
                    {
                        //Getting FileName
                        fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');

                        //Assigning Unique Filename (Guid)
                        var myUniqueFileName = Convert.ToString(Guid.NewGuid());

                        //Getting file Extension
                        var FileExtension = Path.GetExtension(fileName);

                        // concating  FileName + FileExtension
                        newFileName = myUniqueFileName + FileExtension;

                        // Combines two strings into a path.
                        fileName = Path.Combine(_environment.WebRootPath, "demoImages") + $@"\{newFileName}";

                        // if you want to store path of folder in database
                        PathDB = "demoImages/" + newFileName;

                        using (FileStream fs = System.IO.File.Create(fileName))
                        {
                            file.CopyTo(fs);
                            fs.Flush();
                        }
                    }
                }

            string Nombre_Producto = producto.Nombre_Producto;
            double Precio = producto.Precio;
            string Nombre_Imagen = newFileName;
            string Ruta_Imagen = PathDB;
            int Candidad_Disponible = producto.Candidad_Disponible;
            int Id_Categoria = producto.Id_Categoria;

            var connectionBuilder = new SqliteConnectionStringBuilder();
            connectionBuilder.DataSource = "NuestraBaseDeDatos.Sqlite";
            using(var con = new SqliteConnection(connectionBuilder.ConnectionString))
            {
                con.Open();
                string query = "INSERT INTO Producto (Nombre_Producto, Precio, Candidad_Disponible, Nombre_Imagen, Ruta_Imagen, Id_Categoria) VALUES('"+Nombre_Producto+"', '"+Precio+"', '"+Candidad_Disponible+"', '"+Nombre_Imagen+"', '"+Ruta_Imagen+"', '"+Id_Categoria+"');";
                var cmd = new SqliteCommand(query, con);
                cmd.ExecuteNonQuery();

                con.Close();
            }

            }

             ViewBag.Id_Categoria = new SelectList(_context.Categoria, "Id", "Nombre_Categoria");

            var ListaDeProductos = _context.Producto.Include(X => X.Categoria).ToList();

            return View("ConfiguracionProductos", ListaDeProductos);
        }

        /*public IActionResult EditarProducto()
        {
            return View();
        }*/

        public bool ExisteProducto(int id)
        {
            return(_context.Producto.Any(x=>x.Id==id));
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarProducto(Producto producto, int Id)
        {

            var newFileName = string.Empty;

            if (HttpContext.Request.Form.Files != null)
            {
                var fileName = string.Empty;
                string PathDB = string.Empty;

                var files = HttpContext.Request.Form.Files;

                foreach (var file in files)
                {
                    if (file.Length > 0)
                    {
                        //Getting FileName
                        fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');

                        //Assigning Unique Filename (Guid)
                        var myUniqueFileName = Convert.ToString(Guid.NewGuid());

                        //Getting file Extension
                        var FileExtension = Path.GetExtension(fileName);

                        // concating  FileName + FileExtension
                        newFileName = myUniqueFileName + FileExtension;

                        // Combines two strings into a path.
                        fileName = Path.Combine(_environment.WebRootPath, "demoImages") + $@"\{newFileName}";

                        // if you want to store path of folder in database
                        PathDB = "demoImages/" + newFileName;

                        using (FileStream fs = System.IO.File.Create(fileName))
                        {
                            file.CopyTo(fs);
                            fs.Flush();
                        }
                    }
                }

                

            if (Id != producto.Id)
            {
                return NotFound();
            }
                producto.Nombre_Imagen = newFileName;
                producto.Ruta_Imagen = PathDB;

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(producto);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExisteProducto(producto.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                
                var ListaDeProductos = _context.Producto.Include(X => X.Categoria).ToList();
                return View("ConfiguracionProductos", ListaDeProductos);
            }
            }
            
            return View(producto);
        }

        
        public async Task<IActionResult> EditarProducto(int? IdProducto)
        {
            if (IdProducto == null)
            {
                return NotFound();
            }

            var producto = await _context.Producto.FindAsync(IdProducto);
            if (producto == null)
            {
                return NotFound();
            }
            ViewBag.Id_Categoria = new SelectList(_context.Categoria, "Id", "Nombre_Categoria");
            return View(producto);
        }

        [HttpPost][ValidateAntiForgeryToken]
        public async Task<IActionResult> BorrarProducto(Producto producto, int Id)
        {

            var newFileName = string.Empty;

            if (HttpContext.Request.Form.Files != null)
            {
                var fileName = string.Empty;
                string PathDB = string.Empty;

                var files = HttpContext.Request.Form.Files;

                foreach (var file in files)
                {
                    if (file.Length > 0)
                    {
                        //Getting FileName
                        fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');

                        //Assigning Unique Filename (Guid)
                        var myUniqueFileName = Convert.ToString(Guid.NewGuid());

                        //Getting file Extension
                        var FileExtension = Path.GetExtension(fileName);

                        // concating  FileName + FileExtension
                        newFileName = myUniqueFileName + FileExtension;

                        // Combines two strings into a path.
                        fileName = Path.Combine(_environment.WebRootPath, "demoImages") + $@"\{newFileName}";

                        // if you want to store path of folder in database
                        PathDB = "demoImages/" + newFileName;

                        using (FileStream fs = System.IO.File.Create(fileName))
                        {
                            file.CopyTo(fs);
                            fs.Flush();
                        }
                    }
                }


            if (Id != producto.Id)
            {
                return NotFound();
            }
                producto.Nombre_Imagen = "vacio";
                producto.Ruta_Imagen = "vacio";

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Remove(producto);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExisteProducto(producto.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(ConfiguracionProductos));
            }
            }
            return View(producto);
        }

        
        public async Task<IActionResult> BorrarProducto(int? IdProducto)
        {
            if (IdProducto == null)
            {
                return NotFound();
            }

            var producto = await _context.Producto.FindAsync(IdProducto);
            if (producto == null)
            {
                return NotFound();
            }
            return View(producto);
        }
        
        public async Task<IActionResult> ListaProductos()
        {

            var productos = _context.Producto.Include(X => X.Categoria);

            return View(await productos.ToListAsync());
        }


        public async Task<IActionResult> ConfiguracionProductos()
        {
            var productos = _context.Producto.Include(X => X.Categoria);

            return View(await productos.ToListAsync());
        }



    }

}