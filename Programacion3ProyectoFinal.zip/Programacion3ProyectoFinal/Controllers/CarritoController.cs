﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Tarea.Data;
using Tarea.Models;

namespace Tarea.Controllers
{
    [Authorize(Roles = "Cliente")]
    public class CarritoController : Controller
    {

        private readonly ApplicationDbContext _database;
        private readonly UserManager<Otra_Info_De_Usuario> _userManager;
        public CarritoController(ApplicationDbContext database,
            UserManager<Otra_Info_De_Usuario> userManager)
        {
            _database = database;
            _userManager = userManager;
        }

        public IActionResult Carrito(string userId)
        {
            if (userId == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var carritoId = _database.Carrito.Where(x => x.Id_Usuario == userId).Select(y => y.Id).FirstOrDefault();
            var carrito = _database.Productos_Carrito.Where(x => x.Id_Carrito == carritoId).Include(y => y.Producto).ToList();
            return View(carrito);
        }

        
        public async Task<IActionResult> ELCarrito(string userId,int productoId)
        {
            if (userId == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var existeCarrito = _database.Carrito.Where(x => x.Id_Usuario == userId).FirstOrDefault();

            if (existeCarrito == null)
            {
                var carrito = new Carrito();
                carrito.Estado = "Abierto";
                carrito.Id_Usuario = userId;
                await _database.Carrito.AddAsync(carrito);
                await _database.SaveChangesAsync();

                var producto = _database.Producto.Where(x => x.Id == productoId).Include(y=>y.Categoria).FirstOrDefault();

                ViewBag.carritoId = carrito.Id;
                return View("DetalleProducto", producto);
            }
            else
            {
                var carrito = _database.Carrito.Where(x => x.Id_Usuario == userId).FirstOrDefault();
                ViewBag.carritoId = carrito.Id;
                var producto = _database.Producto.Where(x => x.Id == productoId).Include(y => y.Categoria).FirstOrDefault();
                return View("DetalleProducto", producto);
            }
        }

        public IActionResult DetalleProducto()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> EnviarAlCarrito(int productoId, int cantidad ,string userId)
        {
            if (productoId == 0 && userId== null)
            {
                return RedirectToAction("Index","Home");
            }

            try
            {
                var existeProducto = (from a in _database.Productos_Carrito
                                      join b in _database.Carrito on a.Id_Carrito equals b.Id
                                      where b.Id_Usuario == userId && a.Id_Producto == productoId
                                      select a.Id_Producto).FirstOrDefault();
                var carritoId = _database.Carrito.Where(x => x.Id_Usuario == userId).Select(y => y.Id).FirstOrDefault();
                Productos_Carrito productoCarrito = new Productos_Carrito();

                if (existeProducto == 0)
                {
                    productoCarrito.Id_Carrito = carritoId;
                    productoCarrito.Id_Producto = productoId;
                    productoCarrito.Cantidad_Producto = cantidad;
                    await _database.Productos_Carrito.AddAsync(productoCarrito);
                    await _database.SaveChangesAsync();

                    var producto = _database.Producto.Where(x => x.Id == productoId).Include(y => y.Categoria).FirstOrDefault();
                    ViewBag.Agregado = "Producto agregado al carrito exitosamente";
                    return View(nameof(DetalleProducto), producto);
                }
                else
                {
                    productoCarrito = _database.Productos_Carrito.Where(x => x.Id_Producto == productoId).FirstOrDefault();
                    productoCarrito.Cantidad_Producto = productoCarrito.Cantidad_Producto + cantidad;
                     _database.Productos_Carrito.Update(productoCarrito);
                    await _database.SaveChangesAsync();

                    var producto = _database.Producto.Where(x => x.Id == productoId).Include(y => y.Categoria).FirstOrDefault();
                    ViewBag.Agregado = "Producto agregado al carrito exitosamente";
                    return View(nameof(DetalleProducto), producto);
                }
                
               
            }
            catch (Exception e)
            {
                ViewBag.error = e.Message;
                return RedirectToAction("Index", "Home");
            }
        }

        public IActionResult Comprar(int productoId, int carritoId,int cantidad)
        {
            if (carritoId == 0 && productoId == 0)
            {
                return NotFound();
            }

           // var carrito = _database.Carrito.Where(x => x.Id == carritoId).Include(y => y.Usuario).FirstOrDefault();

            var carrito = _database.Productos_Carrito.Where(x => x.Id_Carrito == carritoId).Include(y => y.Producto).Include(z=>z.Carrito).FirstOrDefault();
            var producto = _database.Producto.Where(x => x.Id == productoId).FirstOrDefault();           
            Orden orden = new Orden();

            if (carrito != null)
            {
                orden.Cantidad_Producto = carrito.Cantidad_Producto;
                orden.Precio_Unitario = producto.Precio;
                orden.Fecha_Creacion = DateTime.Today;
                orden.Monto_Orden = carrito.Cantidad_Producto * carrito.Producto.Precio;
                orden.Estado = "En Proceso";
                orden.Id_Usuario = carrito.Carrito.Id_Usuario;
                orden.Id_Producto = producto.Id;
                orden.Producto = producto;
                return View(orden);
            }
            else
            {
                orden.Cantidad_Producto = cantidad;
                orden.Precio_Unitario = producto.Precio;
                orden.Fecha_Creacion = DateTime.Today;
                orden.Monto_Orden = orden.Precio_Unitario*cantidad;
                orden.Estado = "En Proceso";
                orden.Id_Producto = producto.Id;
                orden.Producto = producto;
                return View(orden);
            }


        }

        public async Task<IActionResult> ProcesarCompra(Orden orden)
        {
            if (orden == null)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    await _database.Orden.AddAsync(orden);
                    var usuario = _userManager.GetUserId(User);
                    var carritoId = _database.Carrito.Where(x => x.Id_Usuario == usuario).Select(y=>y.Id).FirstOrDefault();
                    var productoCarrito = _database.Productos_Carrito.Where(x => x.Id_Producto == orden.Id_Producto).Where(y => y.Id_Carrito == carritoId).FirstOrDefault();

                    if (productoCarrito != null)
                    {
                        _database.Productos_Carrito.Remove(productoCarrito);
                        var producto = _database.Producto.Where(x => x.Id == productoCarrito.Id_Producto).FirstOrDefault();
                        producto.Candidad_Disponible = producto.Candidad_Disponible - orden.Cantidad_Producto;
                        _database.Producto.Update(producto);
                        await _database.SaveChangesAsync();
                        return View(nameof(Gracias));
                    }
                    else
                    {
                        var producto = _database.Producto.Where(x => x.Id == orden.Id_Producto).FirstOrDefault();
                        producto.Candidad_Disponible = producto.Candidad_Disponible - orden.Cantidad_Producto;
                        _database.Producto.Update(producto);
                        await _database.SaveChangesAsync();
                        return View(nameof(Gracias));
                    }
                     
                }
                catch (Exception)
                {

                    throw;
                }
            }
            return View();
        }

        public IActionResult Gracias()
        {

            return View();
        }
    }
}