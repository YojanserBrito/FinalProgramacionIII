using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Tarea.Data;
using Tarea.Models;

namespace Tarea.Controllers
{
    public class ConfiguracionesController : Controller
    {
        public IActionResult ConfiguracionGeneral()
        {

            return View();
        }


    }
}