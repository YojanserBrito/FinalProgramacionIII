﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tarea.Data;
using Tarea.Models;
using X.PagedList;

namespace Tarea.Controllers
{
    public class ClientesController : Controller
    {
        private readonly ApplicationDbContext database;
        private readonly RoleManager<IdentityRole> roleManager;
        private readonly UserManager<Otra_Info_De_Usuario> userManager;

        public ClientesController(ApplicationDbContext database,UserManager<Otra_Info_De_Usuario> userManager,RoleManager<IdentityRole> roleManager)
        {
            this.roleManager = roleManager;
            this.userManager = userManager;
            this.database = database;
        }

        public IActionResult ListaClientes(int? page,string mes,string mesLetra)
        {
            if (mes == null)
            {
                var numeroDePaginas = page ?? 1;
                var tamayoDePagina = 5;
                var clientes = userManager.Users.ToPagedList(numeroDePaginas, tamayoDePagina);
                ViewData["textoCumpleaños"] = "Cumpleaños en el mes -> Todos";
                ViewData["mesId"] = Convert.ToInt32(mes);
                ViewData["mes"] = mesLetra;
                return View(clientes);
            }
            else
            {
                int mesInt = Convert.ToInt32(mes);
                var numeroDePaginas = page ?? 1;
                var tamayoDePagina = 5;
                var clientes = userManager.Users.Where(x => x.Fecha_Nacimiento.Month == mesInt).ToPagedList(numeroDePaginas, tamayoDePagina);
                ViewData["textoCumpleaños"] = "Cumpleaños en el mes -> "+mesLetra;
                ViewData["mesId"] = Convert.ToInt32(mes);
                ViewData["mes"] = mesLetra;
                return View(nameof(ListaClientes), clientes);
            }
            
        }

        public IActionResult Pedidos_Mapa()
        {
            return View();
        }

        [HttpGet]
        public IActionResult ListaDePedidos(string estado)
        {

            if (estado == "Todas")
            {
                var pedidos = (from a in userManager.Users
                               join b in database.Orden on a.Id equals b.Id_Usuario
                               select new
                               {
                                   a.Nombre,
                                   a.Apellidos,
                                   a.Direccion,
                                   a.Comentario_Direccion,
                                   a.Fecha_Nacimiento,
                                   a.Email,
                                   a.Latitud,
                                   a.Longitud,
                                   b.Monto_Orden,
                                   b.Estado
                               }).ToList();
                return Json(pedidos);
            }
            else
            {
                var pedidos = (from a in userManager.Users
                               join b in database.Orden on a.Id equals b.Id_Usuario
                               where b.Estado == estado
                               select new
                               {
                                   a.Nombre,
                                   a.Apellidos,
                                   a.Direccion,
                                   a.Comentario_Direccion,
                                   a.Fecha_Nacimiento,
                                   a.Email,
                                   a.Latitud,
                                   a.Longitud,
                                   b.Monto_Orden,
                                   b.Estado
                               }).ToList();

                return Json(pedidos);
             }
        }

        public async Task<IActionResult> Ordenes(string id)
        {

            if (id == null)
            {
                return NotFound();
            }

            var ordenes = database.Orden.Include(x => x.Usuario).Include(z=>z.Producto).Where(y => y.Id_Usuario == id).ToListAsync();
            if (ordenes == null)
            {
                return NotFound();
            }
            return View(await ordenes);
        }
                
        public async Task<IActionResult> Detalles(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cliente = await database.Users.FirstOrDefaultAsync(x=>x.Id == id);
            if (cliente == null)
            {
                return NotFound();
            }

            return View(cliente);
        }

        [HttpGet]
        public IActionResult CSV(int mes,string mesLetra)
        {
            var stringBuilder = new StringBuilder();
            stringBuilder.AppendLine("Nombre,Apellidos,Email,Fecha De Nacimiento,Direccion,Latitud,Longitud,Comentario Direccion");
            if (mes == 0)
            {
                var clientesCSV = (from a in database.Users
                                   select new
                                   {
                                       a.Nombre,
                                       a.Apellidos,
                                       a.Email,
                                       a.Fecha_Nacimiento,
                                       a.Direccion,
                                       a.Latitud,
                                       a.Longitud,
                                       a.Comentario_Direccion
                                   }).ToList();
                foreach (var cliente in clientesCSV)
                {
                    stringBuilder.AppendLine($"{cliente.Nombre},{cliente.Apellidos},{cliente.Email},{cliente.Fecha_Nacimiento}," +
                        $"{cliente.Direccion},{cliente.Latitud},{cliente.Longitud},{cliente.Comentario_Direccion}");
                }
            }
            else
            {
                var clientesCSV = (from a in database.Users
                                   where a.Fecha_Nacimiento.Month == mes
                                   select new
                                   {
                                       a.Nombre,
                                       a.Apellidos,
                                       a.Email,
                                       a.Fecha_Nacimiento,
                                       a.Direccion,
                                       a.Latitud,
                                       a.Longitud,
                                       a.Comentario_Direccion
                                   }).ToList();
                foreach (var cliente in clientesCSV)
                {
                    stringBuilder.AppendLine($"{cliente.Nombre},{cliente.Apellidos},{cliente.Email},{cliente.Fecha_Nacimiento}," +
                        $"{cliente.Direccion},{cliente.Latitud},{cliente.Longitud},{cliente.Comentario_Direccion}");
                }
            }
            return File(Encoding.UTF8.GetBytes(stringBuilder.ToString()),"text/csv",$"Cumpleaños de clientes del mes {mesLetra}.csv");
        }

        public async Task<IActionResult> CambiarEstado(int ordenId,string estado)
        {

            if (ordenId == 0)
            {
                return View(nameof(Ordenes));
            }


            if (ModelState.IsValid)
            {
                var laOrden = database.Orden.Where(x => x.Id == ordenId).FirstOrDefault();
                laOrden.Estado = estado;
                database.Orden.Update(laOrden);
               await database.SaveChangesAsync();
                var ordenes = database.Orden.Where(x => x.Id_Usuario == laOrden.Id_Usuario).Include(y=>y.Usuario).Include(z=>z.Producto).ToList();
                return View(nameof(Ordenes), ordenes);
            }
            return RedirectToAction("ConfiguracionGeneral","Configuraciones");
        }

    }
}